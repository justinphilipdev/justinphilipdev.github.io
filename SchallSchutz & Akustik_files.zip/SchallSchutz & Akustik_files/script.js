$(document).ready(function(){ 

	var box = $('#wave-hldr');
	var width = box.width();
	var height = box.height();
	var pnl = $('.wve');   
	var startstop = false;
	var infoelem = "";
	var servicehd = "";
	$('div.sine-img').each(function(){
	infoelem = $(this).attr('id');
	servicehd = $('.service-text.'+infoelem+'').find('h2').text(); 
	$(this).append('<h2>'+servicehd+'</h2>');
	});
	
	function sineHolderAnim (el){
		var left = (Math.random() * (width/18)) | 0;
		var top = (Math.random() * (height/6)) | 0;
		var timeval = "";
		if (left >= top){
			timeval = left;
		}else{
			timeval = top;
		}
		
		var time = "";
		if (timeval <20){
			time = timeval*120;
		}else{
			time = timeval*80;
		}
		el.animate({
			left: left,
			top: top
		}, time,'easeInOutQuad',function(){
				sineHolderAnim(el);
			}
		);	
	}
	sineHolderAnim($('#wave-hldr'));
	
	function sineanimMother (){	
		pnl.each(function sineanim() {
			var left = ((Math.random() * (1.1 - 0.7) + 0.7) * (width / 3)) | 0;
			var time = Math.random() * (8000 - 5000) + 5000 | 0;
			$(this).animate({
				width: left,
			}, time,'easeInOutQuad',sineanim);
		});
	}
	sineanimMother

	$(document).on('mouseenter','div.sine-img.a',function(){
			var infoelem = $(this).attr('id');
			if ($('.service-text.'+infoelem+'').is('.zoomed')){
				return;
			}else{
				$(this).parent('.wve').addClass('zoomed front');
				var bg = $('#'+infoelem+'').css('background-image');
				bg = bg.replace('url(','').replace(')','').replace(/\"/gi, "");
				$('.service-text.'+infoelem+'').addClass('zoomed').css('background-image','url('+bg+')');
				$(this).addClass('zoomed').removeClass('a');
				$('.wve,#wave-hldr').stop(true);
				box.animate({top:'-60px'},200, function(){
					$('.sine-img.zoomed').addClass('x').append('<div class="x-first x-gen"></div><div class="x-second x-gen"></div>');
				});
				$('.wve,div.sine-img').not('.zoomed').animate({'opacity':'0'}).addClass('hidden');
			}
		}
	);	

	$(document).on('click','.sine-img.zoomed.x',function(){
		$('.zoomed').removeClass('zoomed');

		$('.wve.hidden, div.sine-img.hidden').animate({'opacity':'1'},100, function(){
					$('.sine-img.x').removeClass('x')
					$('.x-gen').remove();
				}).removeClass('zoomed');;
		box.animate({top:'0px'},1000,'easeInOutQuint',function(){
			$('.sine-img').addClass('a')
			sineanimMother ();
			sineHolderAnim($('#wave-hldr'));
		});

	  }
	);				
	function scrollToSection(el) {
		var section = el.attr('href'); 
		section = $(''+section+'');
		$('.tmprly-vsbl').removeClass('tmprly-vsbl').addClass('nt-i-vsbl');
		if (section.is('.nt-i-vsbl')){
			section.removeClass('nt-i-vsbl').addClass('tmprly-vsbl');
		}
		$('nav#mainnav').animate({'background-color':'rgb(224, 236, 247)'},100).animate({
			'background-color':'rgba(242, 248, 253, 0.8)'
		}, 500, 'easeInOutBack');	
		$('html, body').animate({'background-color':'rgb(224, 236, 247)'},100).animate({
			'background-color':'#f2f8fd',
			scrollTop: section.offset().top			
		}, 500, 'easeInOutBack')

	}
	$('[data-scroll]').on('click', function(e){
	  e.preventDefault();
	  scrollToSection($(this));
	});
//$(document).on('onSubmit','#contactform',sendForm($(this).serialize()));
	
	function sendForm(data){
		$.ajax({
			type: "POST",
			url: "http://slim-cms.cichowski.me//api/contact",
			headers: {"Consumer": "asd"},
			dataType: "jsonp",
			data:data,
			success: function (data) {
				
			}
		});
	}
var pattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
	$('input, textarea').blur(function(){
	    if($(this).is('.error') && !$(this).val() ){
			return
		}
		else if( !$(this).val()) {
			$(this).addClass('error').removeClass('validated');
			$(this).parent('div').append('<p class="errormsg">Bitte füllen Sie dieses Feld aus.</p>');
		}else{
			$(this).removeClass('error').addClass('validated');
			$(this).parent('div').find('p.errormsg').remove();
		}
	    if( $(this).is('#email') && $(this).val() !== "" ) {
				if(!pattern.test($(this).val())){
				$(this).addClass('error').removeClass('validated');
				$(this).parent('div').append('<p class="errormsg">Bitte geben Sie eine korrete E-Mail-Adresse an.</p>');
				}else{
				$(this).removeClass('error').addClass('validated');
				$(this).parent('div').find('p.errormsg').remove();
			}	
		}	
	});
	$(document).on('submit','#contactform',function(e) {
			
			if(!$("#Dataprotection").is(':checked')){
				e.preventDefault();
				alert('irgendwatt stimmt ni');
				$('.round label').css({'border-color':'red'});
			}else if($('.rqrd.validated').length == $('.rqrd').length){
				alert('Alle Werte sind ausgefüllt');
				return true;
			}else{
				e.preventDefault();
				alert('Validierung fehlgeschlagen');
			}
			
	});

});
